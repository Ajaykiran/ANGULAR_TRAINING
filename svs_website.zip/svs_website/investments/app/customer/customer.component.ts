import { Component } from "../../node_modules/@angular/core";



@Component({
    templateUrl:'./app/customer/customer.component.html',
    styleUrls:['./app/customer/customer.component.css']
})
export class CustomerComponent
{

}