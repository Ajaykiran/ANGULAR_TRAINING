import { Injectable } from "../../node_modules/@angular/core";
import { firstHolderData } from "../data/firstholderdata";

@Injectable()
export class FirstHolderService{

    getFirstHolderData():Promise<any>
    {

        return  Promise.resolve(firstHolderData);
    }


}