import { Injectable } from "../../node_modules/@angular/core";
import { menuData } from "../data/menudata";

@Injectable()
export class MenuService{

    getMenuData():Promise<string[]>
    {

        return  Promise.resolve(menuData);
    }


}