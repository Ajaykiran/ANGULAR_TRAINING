import {Component} from '@angular/core';
//import { Student } from '../data/student';

@Component({
    selector: 'input-output',
    templateUrl:'./app/investment/investment.component.html',
    styleUrls:['./app/investment/investment.component.css']
    
})
export class InvestmentComponent {

      //property binding	
       private receiptType:string;
       private certificateDate:Date;
       private tenure:string;
       private investmentType:string;
       private investmentAmount:number;
       private maturityDate:Date;
       private maturityInstructions:string
       
       constructor()
       {
	       this.receiptType="Both";
	       this.certificateDate=new Date(2016,4,4);
	       this.investmentAmount=500000;
	       this.tenure="12 months";
	       this.investmentType="Quarterly Interest Payout";
	       this.maturityDate=new Date(2022,1,1);
	       this.maturityInstructions="Renew Principal only on Maturity";
       }	

       saveData(obj) {
	console.log("Event Raised....");
         }		
     		
      
				
}  

