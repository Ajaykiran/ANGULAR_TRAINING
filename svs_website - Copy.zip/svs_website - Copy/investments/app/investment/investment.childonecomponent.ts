import { Component,Input,Output,EventEmitter, OnInit } 
from "../../node_modules/@angular/core";
import { THIS_EXPR } from "../../node_modules/@angular/compiler/src/output/output_ast";


@Component({
	selector: 'child-one',
	templateUrl:'./app/investment/investment.childonecomponent.html',
	styleUrls:['./app/investment/investment.childonecomponent.css']
    
})
export class ChildOneComponent implements OnInit  {
	@Input() 
	childReceiptType : string; 
	@Input()
	childCertificateDate:Date;
	@Input()
	childTenure:string;
	@Input()
	childInvestmentType:string;
	@Input()
	childInvestmentAmount:number;
	@Input()
	childMaturityDate:Date;
	@Input()
	childMaturityInstructions:string;	
  	@Output('addInvestment') 
	addInvestmentEvent = new EventEmitter<any>();
	private cdate:string;
	private mdate:string;

	ngOnInit()
	{
		 console.log(this.childCertificateDate);
		 if(this.childCertificateDate.getFullYear()>0)
		 {
			 //certificate date
			 this.cdate=this.childCertificateDate.getDate()+"/"+
			 this.childCertificateDate.getMonth()+"/"+
			 this.childCertificateDate.getDay();
             //maturity date
			 this.mdate=this.childMaturityDate.getDate()+"/"+
			 this.childMaturityDate.getMonth()+"/"+
			 this.childMaturityDate.getDay();
		 }
	}
	

  		
	addChildInvestment() {
	      this.addInvestmentEvent.emit();
        }	
		
} 

