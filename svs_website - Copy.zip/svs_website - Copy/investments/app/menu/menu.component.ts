import { OnInit, Component } from "../../node_modules/@angular/core";
import { MenuService } from "../services/menuservice";
@Component({
    selector:'svs-menu',
    templateUrl:'./app/menu/menu.component.html',
    styleUrls:['./app/menu/menu.component.css']
})
export class MenuComponent implements OnInit
{

    private menu:any=[];
    constructor(private obj:MenuService)
    {

    }
    ngOnInit()
    {
        this.obj.getMenuData().then(response=>{
            response.forEach(elem=>{
                this.menu.push(elem);
            })
              
        })

    }
}